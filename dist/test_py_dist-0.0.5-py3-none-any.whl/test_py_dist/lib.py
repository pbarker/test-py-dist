

def foo() -> str:
    return "bar"