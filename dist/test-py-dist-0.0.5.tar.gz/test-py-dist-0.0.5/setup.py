# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_py_dist']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'test-py-dist',
    'version': '0.0.5',
    'description': '',
    'long_description': None,
    'author': 'Patrick Barker',
    'author_email': 'pbarker@onemedical.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
